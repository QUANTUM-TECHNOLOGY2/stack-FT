# 🎨 Quantum Technology - Gestionnaire de fiches techniques

**Application Django 5.2 + Supabase PostgreSQL avec fallback HTTP client**

## 📋 État du Projet

✅ **Production-Ready** — Version finale testée et déployée
- Backend : Supabase PostgreSQL distant
- Authentification : Supabase Auth + JWT
- Stockage : Supabase Storage (bucket `fiches`)
- Migrations : 18/18 appliquées ✓
- Mode : Remote Supabase (`USE_LOCAL_BACKEND=0`)

## 🚀 Démarrage Rapide

### 1. Environnement virtuel
```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Configuration
Copiez .env.example vers .env et ajustez les variables si vous souhaitez brancher Supabase.

## Démarrage
```powershell
python deepseek_python_20260708_1a153f.py
```

L’application sera disponible sur http://localhost:8000.

## Validation des imports
- Seuls les fichiers PDF sont acceptés.
- Taille maximale : 50 MB.

## Supabase
- Si vous utilisez Supabase, copiez `.env.example` vers `.env` et remplissez :
  - `SUPABASE_URL`
  - `SUPABASE_KEY`
  - `SUPABASE_SERVICE_KEY`
  - `USE_LOCAL_BACKEND=0`
- Assurez-vous que les tables suivantes existent : `profiles`, `tags`, `fiches`, `fiche_tags`, `versions`, `notifications`.
- Créez aussi le bucket de stockage `fiches` dans Supabase Storage et rendez-le public ou configurez les règles.
- Pour coller le SQL dans Supabase, utilisez l'éditeur SQL et exécutez le script fourni dans la conversation.
- Lancez l’application avec : `python deepseek_python_20260708_1a153f.py`
